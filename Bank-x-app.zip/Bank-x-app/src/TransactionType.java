
public enum TransactionType {
Deposit,
Withdrawl,
Transfer
	
	
}
